import {  IsNotEmpty, MinLength } from 'class-validator';


export class BookingDto {
  @IsNotEmpty()
  carId: number;


  @IsNotEmpty()
  customerName: string;

  @IsNotEmpty()
  customerEmail: string;

  @IsNotEmpty()
  pickupLocation: string;

  @IsNotEmpty()
  destinationLocation: string;

  

  
}