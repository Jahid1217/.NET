import { Controller, Get, Patch, Delete, Body, Param, Headers, UseGuards,UsePipes,ValidationPipe } from '@nestjs/common';
import { UserService } from './user.service';
import { createuser } from 'src/user/user/DTO/user.dto';
import { UnauthorizedException } from '@nestjs/common';

@Controller('profile')
export class UserController {
  constructor(private readonly userService: UserService) {}

  // View profile
  @Get('view')
  async viewProfile(@Headers('Authorization') authorizationHeader: string) {
    if (!authorizationHeader) {
      throw new UnauthorizedException('Authorization token is required');
    }

    const token = this.extractToken(authorizationHeader);
    return this.userService.viewProfile(token);
  }

  // Update profile
  @Patch('update')
  @UsePipes(new ValidationPipe())
  async updateProfile(
    @Headers('Authorization') authorizationHeader: string,
    @Body() updateUserDto: createuser,
  ) {
    if (!authorizationHeader) {
      throw new UnauthorizedException('Authorization token is required');
    }

    const token = this.extractToken(authorizationHeader);
    return this.userService.updateProfile(token, updateUserDto);
  }

  // Delete profile
  @Delete('delete')
  async deleteProfile(@Headers('Authorization') authorizationHeader: string) {
    if (!authorizationHeader) {
      throw new UnauthorizedException('Authorization token is required');
    }

    const token = this.extractToken(authorizationHeader);
    return this.userService.deleteProfile(token);
  }

  
  private extractToken(authorizationHeader: string): string {
    const parts = authorizationHeader.split(' ');
    if (parts.length === 2 && parts[0] === 'Bearer') {
      return parts[1];
    } else {
      throw new UnauthorizedException('Invalid token format');
    }
  }
}


