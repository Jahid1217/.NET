﻿using MidAssignment.Context;
using System.Web.Mvc;
using MidAssignment.Context;

namespace YourNamespace.Controllers
{
    public class StudentController : Controller
    {
        // Show the form with Standard HTML Helpers
        public ActionResult StandardTyped()
        {
            return View();
        }

        [HttpPost]
        public ActionResult StandardTyped(student student)
        {
            if (ModelState.IsValid)
            {
                // Save to DB (not implemented here)
                return RedirectToAction("Success");
            }
            return View(student);
        }

        // Show the form with Strongly Typed HTML Helpers
        public ActionResult StronglyTyped()
        {
            return View(new student());
        }

        [HttpPost]
        public ActionResult StronglyTyped(student student)
        {
            if (ModelState.IsValid)
            {
                // Save to DB (not implemented here)
                return RedirectToAction("Success");
            }
            return View(student);
        }

        // Show the form with Templated Helpers
        public ActionResult TemplatedTyped()
        {
            return View(new student());
        }

        [HttpPost]
        public ActionResult TemplatedTyped(student student)
        {
            if (ModelState.IsValid)
            {
                // Save to DB (not implemented here)
                return RedirectToAction("Success");
            }
            return View(student);
        }

        public ActionResult Success()
        {
            return Content("Student created successfully!");
        }
    }
}
