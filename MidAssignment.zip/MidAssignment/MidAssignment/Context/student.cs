namespace MidAssignment.Context
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Collections.Generic;
    
    public partial class student
    {
        public int id { get; set; }

        [Required(ErrorMessage = "First name is required")]
        [Display(Name = "First Name")]

        public string first_name { get; set; }


        [Required(ErrorMessage = "Last name is required")]
        [Display(Name = "Last Name")]
        public string last_name { get; set; }


        [Required(ErrorMessage = "Date of birth is required")]
        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        public System.DateTime DOB { get; set; }


        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        [Display(Name = "Email Address")]
        public string email { get; set; }


        [Required(ErrorMessage = "Phone number is required")]
        [Phone(ErrorMessage = "Invalid phone number")]
        [Display(Name = "Phone Number")]
        public string phone { get; set; }
        
        
        [Required(ErrorMessage = "CGPA is required")]
        [Range(0.0, 4.0, ErrorMessage = "CGPA must be between 0.0 and 4.0")]
        [Display(Name = "CGPA")]
        public double cgpa { get; set; }
        
        
        [Required(ErrorMessage = "Blood group is required")]
        [Display(Name = "Blood Group")]
        public string Blood_Group { get; set; }
    }
}
